import * as React from "react"
import { useTheme } from "@/design-system/hooks"

/**
 * Cores de fundo variadas para o Light Mode (verde pastel)
 * Conforme AnestHomeFinalPreview.jsx linha 37-40
 */
const LIGHT_BG_COLORS = ['#B8E0C8', '#A8D5BA', '#C5E8D5', '#D4EDDA']

/**
 * Ícone de Calendário customizado
 * Conforme referências oficiais
 */
function CalendarIcon({ isDark }) {
  const strokeColor = isDark ? '#2ECC71' : '#004225'

  return (
    <svg
      width="24"
      height="24"
      viewBox="0 0 24 24"
      fill="none"
      stroke={strokeColor}
      strokeWidth="2"
      aria-hidden="true"
    >
      <rect x="3" y="4" width="18" height="18" rx="2" />
      <path d="M16 2v4" />
      <path d="M8 2v4" />
      <path d="M3 10h18" />
    </svg>
  )
}

/**
 * Gera um índice baseado no hash da string para selecionar cor de fundo
 */
function getColorIndex(hospital, data, hora) {
  const str = `${hospital || ''}|${data || ''}|${hora || ''}`
  let hash = 0
  for (let i = 0; i < str.length; i++) {
    hash = (hash * 31 + str.charCodeAt(i)) | 0
  }
  return Math.abs(hash) % LIGHT_BG_COLORS.length
}

/**
 * PlantaoListItem - Item de lista de plantões
 * 
 * Baseado em:
 * - AnestHomeFinalPreview.jsx linhas 262-278 (Light Mode)
 * - AnestHomeDark.jsx linhas 311-337 (Dark Mode)
 * 
 * LIGHT MODE:
 *   - Container ícone: bg cores variadas (#B8E0C8, #A8D5BA, etc), SEM border
 *   - Ícone: stroke #004225
 *   - Nome: #000000
 *   - Data: #9CA3AF
 *   - Hora: #9BC53D
 * 
 * DARK MODE:
 *   - Container ícone: bg #243530, border 1px #2A3F36
 *   - Ícone: stroke #2ECC71
 *   - Nome: #FFFFFF
 *   - Data: #6B8178
 *   - Hora: #2ECC71 com glow
 */
function PlantaoListItem({
  hospital,
  data,
  hora,
  index,
  bgColor,
  isLast = false,
  showDivider = true,
  onClick,
  className,
  ...props
}) {
  const { isDark } = useTheme()

  // Calcular cor de fundo para Light Mode (se não fornecida via prop)
  const colorIndex = index !== undefined ? index : getColorIndex(hospital, data, hora)
  const lightBgColor = bgColor || LIGHT_BG_COLORS[colorIndex % LIGHT_BG_COLORS.length]

  // Estilo do container do ícone
  const iconContainerStyle = isDark
    ? {
        width: '48px',
        height: '48px',
        borderRadius: '12px',
        background: '#243530',
        border: '1px solid #2A3F36',
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center',
      }
    : {
        width: '48px',
        height: '48px',
        borderRadius: '12px',
        background: lightBgColor,
        // SEM border no Light Mode
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center',
      }

  // Cores dos textos
  const hospitalColor = isDark ? '#FFFFFF' : '#000000'
  const dataColor = isDark ? '#6B8178' : '#9CA3AF'
  const horaColor = isDark ? '#2ECC71' : '#9BC53D'

  // Estilo do horário (com textShadow/glow no dark mode)
  const horaStyle = isDark
    ? {
        fontSize: '15px',
        fontWeight: 700,
        color: horaColor,
        textShadow: '0 0 10px rgba(46, 204, 113, 0.15)',
      }
    : {
        fontSize: '15px',
        fontWeight: 700,
        color: horaColor,
      }

  // Cor do divisor
  const dividerColor = isDark ? '#2A3F36' : '#F3F4F6'

  // Determinar se deve mostrar divisor
  const shouldShowDivider = showDivider && !isLast

  return (
    <div
      style={{
        display: 'flex',
        alignItems: 'center',
        gap: '14px',
        padding: '14px 0',
        borderBottom: shouldShowDivider ? `1px solid ${dividerColor}` : 'none',
        cursor: onClick ? 'pointer' : 'default',
      }}
      onClick={onClick}
      className={className}
      {...props}
    >
      {/* Container do Ícone */}
      <div style={iconContainerStyle}>
        <CalendarIcon isDark={isDark} />
      </div>

      {/* Conteúdo */}
      <div style={{ flex: 1, minWidth: 0 }}>
        <p style={{
          fontSize: '15px',
          fontWeight: 600,
          color: hospitalColor,
          margin: 0,
          overflow: 'hidden',
          textOverflow: 'ellipsis',
          whiteSpace: 'nowrap',
        }}>
          {hospital}
        </p>
        <p style={{
          fontSize: '13px',
          color: dataColor,
          margin: '2px 0 0 0',
        }}>
          {data}
        </p>
      </div>

      {/* Horário */}
      <span style={horaStyle}>
        {hora}
      </span>
    </div>
  )
}

export { PlantaoListItem }
