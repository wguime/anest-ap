import * as React from "react"
import { motion } from "framer-motion"
import { Settings } from "lucide-react"
import { useTheme } from "@/design-system/hooks"
import { cn } from "@/design-system/utils/tokens"

/**
 * Ícones SVG customizados - EXATAMENTE como nas referências oficiais
 * 
 * LIGHT MODE: Todos os ícones são BRANCOS (#FFFFFF)
 * DARK MODE: 
 *   - Highlighted (Calculadoras): #0A0F0D (escuro)
 *   - Não highlighted: #2ECC71 (verde)
 */
function CustomIcon({ index, isDark, isHighlighted }) {
  // Definir cores baseado no modo e estado
  let strokeColor, fillColor
  
  if (isDark) {
    // DARK MODE
    if (isHighlighted) {
      strokeColor = "#0A0F0D"
      fillColor = "#0A0F0D"
    } else {
      strokeColor = "#2ECC71"
      fillColor = "#2ECC71"
    }
  } else {
    // LIGHT MODE - sempre branco
    strokeColor = "#FFFFFF"
    fillColor = "#FFFFFF"
  }

  // Calculadora (index 0)
  if (index === 0) {
    return (
      <svg
        width="24"
        height="24"
        viewBox="0 0 24 24"
        fill="none"
        stroke={strokeColor}
        strokeWidth="1.5"
        aria-hidden="true"
      >
        <rect x="4" y="2" width="16" height="20" rx="2" />
        <rect x="6" y="4" width="12" height="5" rx="1" />
        <circle cx="8" cy="12" r="1" fill={fillColor} />
        <circle cx="12" cy="12" r="1" fill={fillColor} />
        <circle cx="16" cy="12" r="1" fill={fillColor} />
        <circle cx="8" cy="16" r="1" fill={fillColor} />
        <circle cx="12" cy="16" r="1" fill={fillColor} />
        <circle cx="16" cy="16" r="1" fill={fillColor} />
      </svg>
    )
  }

  // Reportar/Alerta (index 1)
  if (index === 1) {
    return (
      <svg
        width="24"
        height="24"
        viewBox="0 0 24 24"
        fill="none"
        stroke={strokeColor}
        strokeWidth="1.5"
        aria-hidden="true"
      >
        <path d="M12 9v4" />
        <path d="M12 17h.01" />
        <path d="M10.29 3.86L1.82 18a2 2 0 001.71 3h16.94a2 2 0 001.71-3L13.71 3.86a2 2 0 00-3.42 0z" />
      </svg>
    )
  }

  // Manutenção/Ferramenta (index 2)
  if (index === 2) {
    return (
      <svg
        width="24"
        height="24"
        viewBox="0 0 24 24"
        fill="none"
        stroke={strokeColor}
        strokeWidth="1.5"
        aria-hidden="true"
      >
        <path d="M14.7 6.3a1 1 0 000 1.4l1.6 1.6a1 1 0 001.4 0l3.77-3.77a6 6 0 01-7.94 7.94l-6.91 6.91a2.12 2.12 0 01-3-3l6.91-6.91a6 6 0 017.94-7.94l-3.76 3.76z" />
      </svg>
    )
  }

  // Desafio ROPs/Alvo (index 3)
  if (index === 3) {
    return (
      <svg
        width="24"
        height="24"
        viewBox="0 0 24 24"
        fill="none"
        stroke={strokeColor}
        strokeWidth="1.5"
        aria-hidden="true"
      >
        <circle cx="12" cy="12" r="10" />
        <circle cx="12" cy="12" r="6" />
        <circle cx="12" cy="12" r="2" />
      </svg>
    )
  }

  return null
}

/**
 * QuickLinksGrid - Grid de Atalhos Rápidos estilo iPhone
 * 
 * Baseado em:
 * - AnestHomeFinalPreview.jsx (Light Mode)
 * - AnestHomeDark.jsx (Dark Mode)
 */
function QuickLinksGrid({
  title = "Atalhos Rápidos",
  onCustomize,
  items = [],
  className,
  ...props
}) {
  const { isDark } = useTheme()
  const [pressedIndex, setPressedIndex] = React.useState(null)

  /**
   * Estilos do círculo do atalho
   * 
   * LIGHT MODE:
   *   - Não highlighted: bg #004225, sem border, shadow rgba(0,66,37,0.25)
   *   - Highlighted: gradient #006837→#004225, border 2px #9BC53D, shadow rgba(0,66,37,0.4)
   * 
   * DARK MODE:
   *   - Não highlighted: bg #243530, border 1px #2A3F36, shadow rgba(0,0,0,0.3)
   *   - Highlighted: gradient #2ECC71→#1E8449, sem border, shadow rgba(46,204,113,0.4)
   */
  const getCircleStyle = (isHighlighted, index) => {
    const isPressed = pressedIndex === index
    const baseStyle = {
      width: '54px',
      height: '54px',
      borderRadius: '50%',
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      cursor: 'pointer',
      transform: isPressed ? 'scale(0.92)' : 'scale(1)',
      transition: 'transform 0.15s ease',
    }

    if (isDark) {
      // DARK MODE
      if (isHighlighted) {
        return {
          ...baseStyle,
          background: 'linear-gradient(135deg, #2ECC71 0%, #1E8449 100%)',
          boxShadow: '0 6px 20px rgba(46, 204, 113, 0.4)',
          // SEM border no highlighted dark
        }
      } else {
        return {
          ...baseStyle,
          background: '#243530',
          border: '1px solid #2A3F36',
          boxShadow: '0 4px 12px rgba(0,0,0,0.3)',
        }
      }
    } else {
      // LIGHT MODE
      if (isHighlighted) {
        return {
          ...baseStyle,
          background: 'linear-gradient(135deg, #006837 0%, #004225 100%)',
          border: '2px solid #9BC53D',
          boxShadow: '0 6px 16px rgba(0,66,37,0.4)',
        }
      } else {
        return {
          ...baseStyle,
          background: '#004225',
          boxShadow: '0 4px 12px rgba(0,66,37,0.25)',
          // SEM border no não-highlighted light
        }
      }
    }
  }

  // Cores de texto
  const titleColor = isDark ? '#FFFFFF' : '#000000'
  const customizeColor = isDark ? '#2ECC71' : '#006837'
  const labelColor = isDark ? '#6B8178' : '#6B7280'

  // Estilo do container
  const containerStyle = isDark
    ? {
        background: '#1A2420',
        borderRadius: '20px',
        padding: '20px',
        marginBottom: '16px',
        border: '1px solid #2A3F36',
      }
    : {
        background: '#FFFFFF',
        borderRadius: '20px',
        padding: '20px',
        marginBottom: '16px',
        boxShadow: '0 2px 12px rgba(0,66,37,0.06)',
      }

  return (
    <div style={containerStyle} className={className} {...props}>
      {/* Header */}
      <div style={{
        display: 'flex',
        justifyContent: 'space-between',
        alignItems: 'center',
        marginBottom: '14px',
      }}>
        <h3 style={{
          fontSize: '16px',
          fontWeight: 700,
          color: titleColor,
          margin: 0,
        }}>
          {title}
        </h3>
        <button
          type="button"
          onClick={onCustomize}
          style={{
            fontSize: '13px',
            fontWeight: 600,
            color: customizeColor,
            display: 'flex',
            alignItems: 'center',
            gap: '4px',
            background: 'none',
            border: 'none',
            cursor: 'pointer',
            padding: 0,
          }}
        >
          <Settings size={14} color={customizeColor} />
          Personalizar
        </button>
      </div>

      {/* Grid de Atalhos */}
      <div style={{ display: 'flex', justifyContent: 'space-between' }}>
        {items.map((item, index) => {
          const isHighlighted = Boolean(item.highlighted || item.destaque || index === 0)

          return (
            <div
              key={index}
              style={{
                display: 'flex',
                flexDirection: 'column',
                alignItems: 'center',
                gap: '8px',
                width: '70px',
              }}
            >
              <motion.div
                style={getCircleStyle(isHighlighted, index)}
                onMouseDown={() => setPressedIndex(index)}
                onMouseUp={() => setPressedIndex(null)}
                onMouseLeave={() => setPressedIndex(null)}
                onTouchStart={() => setPressedIndex(index)}
                onTouchEnd={() => setPressedIndex(null)}
                onClick={item.onClick}
                whileTap={{ scale: 0.92 }}
              >
                <CustomIcon
                  index={index}
                  isDark={isDark}
                  isHighlighted={isHighlighted}
                />
              </motion.div>
              <span style={{
                fontSize: '10px',
                fontWeight: 500,
                color: labelColor,
                textAlign: 'center',
              }}>
                {item.label || item.nome}
              </span>
            </div>
          )
        })}
      </div>
    </div>
  )
}

export { QuickLinksGrid }
